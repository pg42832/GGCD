import org.apache.curator.framework.recipes.locks.InterProcessReadWriteLock;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.parquet.avro.AvroParquetInputFormat;
import org.apache.parquet.avro.AvroParquetOutputFormat;

import java.io.IOException;

public class MovieCount {

    public static class MovieCountMapper extends Mapper<Object, Text, IntWritable, IntWritable> {
        private final static IntWritable UM = new IntWritable(1);
        private final static IntWritable YEAR = new IntWritable();
        private static final String TYPE_MOVIE = "movie";

        // Suposto formato [tconst] [titleType] [primaryTitle] [originalTitle] [isAdult] [startYear]
        // [endYear] [runtimeMinutes] [averageRating] [numVotes] [genres[genre]]

        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String[] tokens = value.toString().split( "\\t");


            if(tokens.length >= 9 && tokens[1].equals(TYPE_MOVIE)) {
                int year = Integer.parseInt(tokens[5]);
                YEAR.set(year);
                context.write(YEAR, UM);
            }
        }
    }

    public static class MovieCountReducer extends Reducer<IntWritable, IntWritable, IntWritable, IntWritable> {
        private IntWritable result = new IntWritable();

        @Override
        protected void reduce(IntWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            int movieCountPorAno = 0;
            for (IntWritable count: values) {
                movieCountPorAno++;
            }
            result.set(movieCountPorAno);
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException,InterruptedException {

        Job job = Job.getInstance(new Configuration(), "MovieCountJob");
        job.setJarByClass(MovieCount.class);
        job.setMapperClass(MovieCountMapper.class);
        job.setReducerClass(MovieCountReducer.class);

        job.setMapOutputKeyClass(IntWritable.class);
        job.setMapOutputValueClass(IntWritable.class);

        /**
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(IntWritable.class);
         */
        job.setInputFormatClass(AvroParquetInputFormat.class);
        job.setOutputFormatClass(AvroParquetOutputFormat.class);

        /**
        FileInputFormat.addInputPath(job, new Path("src/title.basics.tsv.gz"));
        FileOutputFormat.setOutputPath(job, new Path( "outputMovie" ));
         */

        AvroParquetInputFormat.addInputPath(job, new Path("outputParquet"));
        AvroParquetOutputFormat.setSchema(job, ToParquet.getSchema("src/main/schemas/AvroParquetResult.parquet"));
        FileOutputFormat.setOutputPath(job, new Path("resultsMovieCount"));

        job.waitForCompletion( true );
    }
}
