import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.parquet.avro.AvroParquetInputFormat;
import org.apache.parquet.avro.AvroParquetOutputFormat;

import java.io.IOException;

public class MostVoteMovie {


    static class MostVoteMovieMapper extends Mapper<LongWritable, Text, Text, Text> {

        private static final String TYPE_MOVIE = "movie";

        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

            String tokens = value.toString();
            // Suposto formato [tconst] [titleType] [primaryTitle] [originalTitle] [isAdult] [startYear]
            // [endYear] [runtimeMinutes] [averageRating] [numVotes] [genres[genre]]
            String[] tokens_values = tokens.split("\\t");

            // Apenas filmes com mais de 1000 votos para facilitar o processo
            if (Integer.parseInt(tokens_values[9]) > 1000 && tokens_values[1].equals(TYPE_MOVIE))
                context.write(new Text(tokens_values[5]), new Text(tokens_values[9] + "\t" + tokens_values[8] + "\t" + tokens_values[2]));
            //Gera (startYear),(numVotes + averageRating + originalTitle) para cada alinea
        }
    }

    static class MostVoteMovieReducer extends Reducer<Text, Text, Text, Text> {
        public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            float max_rating = Float.MIN_VALUE;
            int max_votes = Integer.MIN_VALUE;
            String[] tokens_values;
            String output = "";
            int vote;
            float rating;

            for (Text value: values) {
                // (numVotes + averageRating + originalTitle)
                tokens_values = value.toString().split("\t");

                // Valores numericos de rating e vote
                rating = Float.parseFloat(tokens_values[1]);
                vote = Integer.parseInt(tokens_values[0]);

                // Ver se os votes é maior que o max_vote
                if (vote > max_votes) {
                    max_votes = vote;
                    max_rating = rating;

                    output = tokens_values[2] + "\t" + tokens_values[0];
                }
                else if (vote == max_votes) {
                    // Decidir pelo rating, caso os votos sejam igual ao max_vote.
                    if (rating > max_rating) {
                        max_rating = rating;
                        max_votes = vote;

                        output = tokens_values[2] + "\t" + tokens_values[0]; }
                } }
            context.write(key, new Text(output));
        }}

    public static void main(String[] args) throws Exception {

        Job job = Job.getInstance(new Configuration(), "MovieVoteMovieJob");
        job.setJarByClass(MostVoteMovie.class);
        job.setMapperClass(MostVoteMovieMapper.class);
        job.setReducerClass(MostVoteMovieReducer.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        /**
         job.setOutputKeyClass(Text.class);
         job.setOutputValueClass(Text.class);
         */

        job.setInputFormatClass(AvroParquetInputFormat.class);
        job.setOutputFormatClass(AvroParquetOutputFormat.class);

        /**
         FileInputFormat.addInputPath(job, new Path("src/title.basics.tsv.gz"));
         FileOutputFormat.setOutputPath(job, new Path( "outputMostVoteMovie" ));
         */

        AvroParquetInputFormat.addInputPath(job, new Path("outputParquet"));
        AvroParquetOutputFormat.setSchema(job, ToParquet.getSchema("src/main/schemas/AvroParquetResult.parquet"));
        FileOutputFormat.setOutputPath(job, new Path("resultsMostVoteMovie"));

        job.waitForCompletion( true );
    }
}
