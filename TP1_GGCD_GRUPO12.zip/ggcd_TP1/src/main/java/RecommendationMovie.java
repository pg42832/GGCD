import org.apache.avro.Schema;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.parquet.avro.AvroParquetInputFormat;
import org.apache.parquet.avro.AvroParquetOutputFormat;
import org.apache.parquet.avro.AvroSchemaConverter;
import org.apache.parquet.schema.MessageType;
import org.apache.parquet.schema.MessageTypeParser;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class RecommendationMovie {

    public static String readFile(String filePath) throws IOException {
        InputStream is = new FileInputStream(filePath);
        String data = new String( IOUtils.toByteArray(is));
        is.close();

        return data;
    }

    public static Schema getSchema(String schemaPath) throws IOException {
        MessageType mt = MessageTypeParser.parseMessageType(readFile(schemaPath));
        return new AvroSchemaConverter().convert(mt);
    }

    public static class RecommendationMovieMapper extends Mapper<LongWritable, Text, Text, Text> {
        //Para armazenar os dados do map
        private Map<String, TreeMap<Float, Text>> mapa = new HashMap<>();
        private TreeMap<Float, Text> moviesMap = new TreeMap<>();
        private final static Text GENRE = new Text();
        private static final String TYPE_MOVIE = "movie";
        private Schema schema;

        // Suposto formato [tconst] [titleType] [primaryTitle] [originalTitle] [isAdult] [startYear]
        // [endYear] [runtimeMinutes] [averageRating] [numVotes] [genres[genre]]

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] tokens = value.toString().split( "\\t" );

            //
            if (tokens.length >= 9 && tokens[1].equals( TYPE_MOVIE )) {
                String genero = (tokens[10].split( "\t" )[0]);
                GENRE.set( genero );
                Float ratings = Float.parseFloat( tokens[8] );
                Text filme = new Text( tokens[2] );
                //se nao existir a chave cria um treeMap (para facilitar trabalho)
                TreeMap<Float, Text> t = mapa.putIfAbsent( genero, new TreeMap<>() );
                try {
                    //Limitar o tamanho do treeMap para 2. Para cada genero uma lista com os 2 melhores filmes
                    t.put( ratings, filme );
                    if (t.size() > 2)
                        t.remove( t.firstKey() );
                } catch (NumberFormatException ex) {
                }
            }
        }

        //Quando acabar todas as funçoes de map.
        //No cleanup vou enviar o TOp2 para cada valor do mapa. Ele executa depois de todos os dados serem processados desta partição.
        @Override
        protected void cleanup(Mapper<LongWritable, Text, Text, Text>.Context context) throws IOException, InterruptedException {
            for (Map.Entry<String, TreeMap<Float, Text>> t : mapa.entrySet()) {
                for (Map.Entry<Float, Text> v : t.getValue().entrySet()) {
                    context.write( new Text( t.getKey() ), new Text( v.getKey() + "\t" + v.getValue() ) );
                    //(genre), (ratings + filme)
                }
            }
        }



    }


    public static class RecommendationMovieReducer extends Reducer<Text, Text, Text, Text> {
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            String[] LINE_values;
            String output = "";
            int vote = 0;
            float rating;
            TreeMap<Float, Text> moviesMap = new TreeMap<>();

            for (Text value: values) {
                LINE_values = value.toString().split("\t");

                try
                {
                    //Limitar o tamanho do treeMap para 2
                    moviesMap.put(Float.parseFloat(LINE_values[0]), new Text(LINE_values[1]));
                    if(moviesMap.size() > 2)
                        moviesMap.remove(moviesMap.firstKey());
                }
                catch(NumberFormatException ex){}
            }


            //Para colocar por ordem descrescente
            for(Map.Entry<Float, Text> t : moviesMap.descendingMap().entrySet()) {
                context.write(new Text(t.getKey().toString()), t.getValue());
            }
        }
    }

    public static void main(String[] args) throws Exception {

        Job job = Job.getInstance(new Configuration(), "RecommendationMovieJob");
        job.setJarByClass(RecommendationMovie.class);
        job.setMapperClass(RecommendationMovieMapper.class);
        job.setReducerClass(RecommendationMovieReducer.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        job.setOutputFormatClass(TextOutputFormat.class);

        AvroParquetInputFormat.setRequestedProjection(job, getSchema("src/main/schemas/ToParquet.parquet" ));
        AvroParquetInputFormat.addInputPath(job, new Path("outputParquet"));
        TextOutputFormat.setOutputPath(job, new Path("resultsRecommendationMovie"));

        job.waitForCompletion( true );
    }
}