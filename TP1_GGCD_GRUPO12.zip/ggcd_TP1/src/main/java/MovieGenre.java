import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.*;

public class MovieGenre {
    public static class MovieGenreMapper extends Mapper<Object, Text, Void, Text> {
        private Map<String, TreeMap<Float,Text>> mapa = new HashMap<>();
        //Assumindo que isto corresponde para cada género o melhor filme.

        // Suposto formato [tconst] [titleType] [primaryTitle] [originalTitle] [isAdult] [startYear]
        // [endYear] [runtimeMinutes] [averageRating] [numVotes] [genres[genre]]
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String token = value.toString();
            String[] tokens = token.split("\\t");

            if(tokens.length >= 9) {
                String nome = (tokens[2]);
                String genero = (tokens[10].split( "\t" )[0]);
                TreeMap<Float, Text> t = mapa.get(genero);
                //Cria um array com os 2 melhores filmes
                // no indice 0 o melhor filme e no indice 1 o segundo melhor filme
                List<Text> array = new ArrayList(t.values());

                String melhorFilme = array.get(0).toString();

                if(melhorFilme.equals(nome)) {
                    melhorFilme = array.get(1).toString();
                }

                context.write(null, new Text(nome + "\t" + melhorFilme));
            }

        }
    }

}
