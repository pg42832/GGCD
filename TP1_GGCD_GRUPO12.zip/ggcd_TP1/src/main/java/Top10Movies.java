import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.parquet.avro.AvroParquetInputFormat;
import org.apache.parquet.avro.AvroParquetOutputFormat;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Top10Movies {

    public static class Top10MoviesMapper extends Mapper<LongWritable, Text, Text, Text> {
        //Para armazenar os dados do map
        private Map<Integer, TreeMap<Float,Text> > mapa = new HashMap<>();
        private TreeMap<Float, Text> moviesMap = new TreeMap<>();
        private final static IntWritable YEAR = new IntWritable();
        private static final String TYPE_MOVIE = "movie";

        // Suposto formato [tconst] [titleType] [primaryTitle] [originalTitle] [isAdult] [startYear]
        // [endYear] [runtimeMinutes] [averageRating] [numVotes] [genres[genre]]

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] tokens = value.toString().split( "\\t");

            //
            if(tokens.length >= 9 && tokens[1].equals(TYPE_MOVIE)) {
                int year = Integer.parseInt(tokens[5]);
                YEAR.set(year);
                //se nao existir a chave cria um treeMap (para facilitar trabalho)
                TreeMap<Float, Text> t = mapa.putIfAbsent(year, new TreeMap<>());
                try
                {
                    //Limitar o tamanho do treeMap para 10
                    t.put(Float.parseFloat(tokens[0]), new Text(value));
                    if(t.size() > 10)
                        t.remove(t.firstKey());
                }
                catch(NumberFormatException ex){}
            }
        }

        //Quando acabar todas as funçoes de map.
        //No cleanup vou enviar o TOp10 para cada valor do mapa. Ele executa depois de todos os dados serem processados desta partição.
        @Override
        protected void cleanup(Mapper<LongWritable, Text, Text, Text>.Context context) throws IOException, InterruptedException {
            for(Map.Entry<Integer, TreeMap<Float, Text>> t : mapa.entrySet()) {
                for(Map.Entry<Float, Text> v : t.getValue().entrySet()) {
                    context.write(new Text(t.getKey().toString()), new Text( v.getKey() + "\t" + v.getValue()));
                }
            }
        }
        //Isto manda o Top10 para cada ano
    }

    public static class Top10MoviesReducer extends Reducer<Text, Text, Text, Text> {
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            float max_rating = Float.MIN_VALUE;
            int max_votes = Integer.MIN_VALUE;
            String[] LINE_values;
            String output = "";
            int vote = 0;
            float rating;
            TreeMap<Float, Text> moviesMap = new TreeMap<>();

            for (Text value: values) {
                LINE_values = value.toString().split("\t");

                try
                {
                    //Limitar o tamanho do treeMap para 10
                    moviesMap.put(Float.parseFloat(LINE_values[0]), new Text(LINE_values[1]));
                    if(moviesMap.size() > 10)
                        moviesMap.remove(moviesMap.firstKey());
                }
                catch(NumberFormatException ex){}
            }

            //Para colocar por ordem descrescente
            for(Map.Entry<Float, Text> t : moviesMap.descendingMap().entrySet()) {
                context.write(new Text(t.getKey().toString()), t.getValue());
            }
        }
    }

    public static void main(String[] args) throws Exception {

        Job job = Job.getInstance(new Configuration(), "Top10MovieJob");
        job.setJarByClass(Top10Movies.class);
        job.setMapperClass(Top10MoviesMapper.class);
        job.setReducerClass(Top10MoviesReducer.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        /**
         job.setOutputKeyClass(Text.class);
         job.setOutputValueClass(Text.class);
         */

        job.setInputFormatClass(AvroParquetInputFormat.class);
        job.setOutputFormatClass(AvroParquetOutputFormat.class);

        /**
         FileInputFormat.addInputPath(job, new Path("src/title.basics.tsv.gz"));
         FileOutputFormat.setOutputPath(job, new Path( "outputTop10Movie" ));
         */

        AvroParquetInputFormat.addInputPath(job, new Path("outputParquet"));
        AvroParquetOutputFormat.setSchema(job, ToParquet.getSchema("src/main/schemas/AvroParquetResult.parquet"));
        FileOutputFormat.setOutputPath(job, new Path("resultsTop10Movies"));

        job.waitForCompletion( true );
    }
}